import controller.Controlador;
import view.Vista;

public class App {

    /**
     * metodo principal (punto de entrada) de la aplicacion
     * crea e inicializa los comppnentes del patron MVC y ejecuta el controlador
     * 
     * @param args argumentos de la linea de comandos (no utilizados en esta aplicacion)
     * @throws Exceptions Manejo de posibles exepciones en la elecucion del programa
     */
    
    public static void main(String[] args) throws Exception {
        System.out.println("Hello Objet-orient programming - MVC Pattern Class");

        //crear componentes MVC
        Vista objVista = new Vista();
        Controlador objControlador = new Controlador(objVista);

        //ejecuta el cpntrolador
        objControlador.ejecutar();

    }
}
// fin del programa