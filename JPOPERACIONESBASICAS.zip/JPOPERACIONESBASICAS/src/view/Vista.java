package view;

import java.util.Scanner;

public class Vista {
    private Scanner scanner; 
    
    /**
     * Constructor de la clase vista 
     * Inicializa el objeto scanner para la entrada de datos desde la consola 
     * 
     */
    public Vista(){
        scanner = new Scanner(System.in); 
    }

    /**
     * Muestra un mensaje en la consola
     * 
     * @param mensaje Mensaje que se mostrara al usuario
     */
    public void mMostrarmensaje(String mensaje){
        System.out.println(mensaje);
    }

    /**
     * Solicita al usuario aun numeor y lo devuelve como un valor tipo double 
     * @param mensaje  Mensaje de solicitud para el usuario
     * @return Numero ingresado por el usuario
     */
    public double mLeerNumero(String mensaje){
        System.out.println(mensaje);
        return scanner.nextDouble();
    }

    /** 
     * Muestra un resultado en la consola junto con un mensaje descriptivo
     * 
     * @param mensaje Mensaje que acompaña el resultado
     * @param resultado Valor numerico a mostrar 
     */
    public void mMostrarResultado(String mensaje, double resultado){
        System.out.println(mensaje + resultado);
    }

    /**
     * cierra el Scanner para luberar recursos y evitar perdidas de memoria
     */
    public void mCerrarScanner(){
        scanner.close();
    }
}