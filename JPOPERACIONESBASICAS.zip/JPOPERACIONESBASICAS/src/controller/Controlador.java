package controller;
import model.Operaciones;
import view.Vista;

public class Controlador {
    /**
     * Objeto de la clase Vista para interactuar con el usuario
     */
    private Vista objVista;

    /**
     * Objeto de la clase Operaciones para realizar calculos matematicos
     */
    private Operaciones objOperaciones;

    /**
     * Constructor de la clase Controlador 
     * 
     * @param vista Objeto de la clave Vista que se utilizara para la interaccion con el usuario
     */
    public Controlador (Vista vista){
        this.objVista = vista;
    }

    /**
     * metodo principal que ejecuta el flujo de la apliocacion
     * Solicita dos numeros al usuario realiza operaciones matematicas y mustra los resultados
     */
    public void ejecutar(){
        //solicitar numeros al usuario 
        double numeroUno = objVista.mLeerNumero("ingrese el primer numero: ");
        double numeroDos = objVista.mLeerNumero("ingrese el segundo nuemero: ");
        
        //crear un objeto de la calse Operaciones
        objOperaciones = new Operaciones();

        // realizar operaciones y mostrar resultado
        objVista.mMostrarResultado("la sumas es ",objOperaciones.mSuma(numeroUno,numeroDos));
        objVista.mMostrarResultado("la resta es ", objOperaciones.mResta(numeroUno,numeroDos));
        objVista.mMostrarResultado("la multiplicacion es ",objOperaciones.mMultiplicacion(numeroUno,numeroDos));

        // cerrar el scanner para liberar recursos
        objVista.mCerrarScanner();

    }

}