package model;

public class Operaciones {
 
    /**
     *  Primer número para realizar las operaciones matematicas
     */
    private double numeroUno;

    /**
     *  Segundo número para realizar las operaciones matematicas 
     */
    private double numeroDos;

    /**
     * Constructor por defecto de la clasr Operaciones 
     * Inicializa los atributos en cero
     */
    public Operaciones (){
        this.numeroUno = 0;
        this.numeroDos = 0;

    }

    /**
     * Constructor sobre cargado que inicializa los valores de los atrivutos.
     * 
     * @param numeroUno Primero numero de las operaciones. 
     * @param numeroDos segundo numero de las operaciones. 
     */
    public Operaciones (double numeroUno, double numeroDos){
        this.numeroUno = numeroUno;
        this.numeroDos = numeroDos; 
    }


    //===================== GETTERS AND SETTERS=================
    /** 
     * Obtienen eñ valor del primer número 
     * 
     * @return Valor de numeroUno
    */
    public double getNumeroUno(){
        return numeroUno;
    }

    /**
     * Establece el valor del primer numero 
     * 
     * @param numeroUno Nuevo valor para numeroUno
     */
    public void setNumeroUno(){
        this.numeroUno = numeroUno;
    }

    /**
     * Obtiene el valor del del segundo numero
     * 
     * @return Valor de numeroDos
     */
    public double getNumeroDos(){
        return numeroDos;
    }

    /**
     * Establece el valor del segundo nuemro 
     * 
     * @param NumeroDos NUevo valor para numeroDos
     */
    public void setNumeroDos(){
        this.numeroDos = numeroDos;
    }

    // ================ METODOS DE OPERACIONES =================

    /**
     * Realiza la suma de dos numeros
     * 
     * @param numeroUno primer numero a sumar 
     * @param numeroDos segundo numero a suamr
     * @return Resultado de la suma  
     */
    public double mSuma(double numeroUno, double numeroDos){
        return numeroUno + numeroDos;
    }

    /**
     * Realiza la resta de dos numero
     * 
     * @param numeroUno primer numero a restar
     * @param numeroDos segundo numero a restar
     * @return Resuktado de la resta
     */
    public double mResta (double numerouno, double numeroDos ){
        return numeroUno - numeroDos;
    }

    /**
     * Realiza la multiplicacion de dos numeros 
     * 
     * @param numeroUno Primer numero a multiplicar
     * @param numeroDos segundo numero a multiplicar
     * @return Resultado de la multiplicacion 
     */
    public double mMultiplicacion ( double numeroUno, double numeroDos){
        return numeroUno * numeroDos;
    }


}